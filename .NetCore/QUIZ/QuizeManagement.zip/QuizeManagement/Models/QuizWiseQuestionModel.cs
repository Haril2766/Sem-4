﻿namespace QuizeManagement.Models
{
    public class QuizWiseQuestionModel
    {
    }
}
