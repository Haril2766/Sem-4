﻿namespace QuizeManagement.Models
{
    public class UserModel
    {
    }
}
