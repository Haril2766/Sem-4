﻿namespace QuizeManagement.Models
{
    public class QuestionLevelModel
    {
        public int UserId { get; set; }
        public string Level { get; set; }
    }
}
